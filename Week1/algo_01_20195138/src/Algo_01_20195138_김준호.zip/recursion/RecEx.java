package recursion;

class RecEx {
	public static void main(String[] args) {
		System.out.println(Rec.fib(10));
	}
}
